# Regras permanentes pra simuladores de goldfish

> Espelho versionado deste repositório do arquivo canônico em
> `references/goldfish-sim-card-rules.md` dentro do skill `mtg-commander`
> (`/root/.claude/skills/synced/mtg-commander/`, fora do controle de versão
> deste repo). O skill é a cópia que eu realmente consulto antes de escrever
> ou editar um simulador — esta aqui existe pra ficar versionada e visível
> no seu histórico do GitHub. Se as duas divergirem, atualize as duas juntas.

Cartas nesta lista precisam ter o efeito real implementado em código em
**qualquer** simulador Python de goldfish que inclua elas — não basta marcar
com uma tag decorativa (`trigger_doubler`, etc). Checar esta lista sempre que
uma carta daqui aparecer na decklist de um simulador novo ou existente.

Adicionada por pedido explícito do usuário (sessão do Thranduil, 2026-08-21):
"Quero que isso seja feito em todos os decks com essa carta daqui em diante."

---

## Roaming Throne

`{4}` Artifact Creature — Golem, 4/4, Ward {2}.

Oracle text (Scryfall): *"As this creature enters, choose a creature type.
This creature is the chosen type in addition to its other types. If a
triggered ability of another creature you control of the chosen type
triggers, it triggers an additional time."*

**O que implementar:**
- **Passo 0, obrigatório antes de qualquer coisa:** varredura MECÂNICA (regex
  em `oracle_text`, não de memória) em toda criatura do tipo escolhido na
  decklist, procurando linhas que comecem com "Whenever"/"At the beginning
  of"/"When ... enters". No Thranduil isso achou 16 criaturas do tipo Elf
  com gatilho próprio - só 4 estavam implementadas antes dessa varredura
  (as "óbvias": motor de draw do comandante, engines de compra, dano de
  combate). As outras 12 tinham o gatilho em si nem modelado ainda, então a
  duplicação delas também estava faltando. **Implementar Roaming Throne sem
  esse passo 0 sempre vai deixar gatilhos de fora.**
- Checar também se alguma carta do tipo escolhido **concede** um gatilho a
  OUTRAS criaturas desse tipo via habilidade estática (ex: Dionus, Elvish
  Archdruid no Thranduil: "Elves you control have 'whenever this becomes
  tapped...'"). Cada criatura que recebe essa habilidade concedida também
  passa a ter um gatilho próprio dobrável - isso multiplica o efeito do
  Roaming Throne além das cartas nomeadas individualmente. Registrar como
  limitação conhecida se não for implementado (é um trabalho maior).
- Rastrear o tipo de criatura escolhido (na prática: o tipo tribal central do
  deck — Elfo, Dragão, Zumbi, etc — é quase sempre a escolha certa; documentar
  a premissa no código se não for óbvio).
- Para CADA gatilho de criatura desse tipo já modelado no simulador (draw
  engines, geradores de token, gatilhos do próprio comandante, etc), disparar
  uma **segunda vez completa** quando o Roaming Throne estiver em campo — não
  só dobrar o número final. Um gatilho que resolve "compre 2, descarte 1" vira
  dois disparos separados de "compre 2, descarte 1", não vira "compre 4,
  descarte 2" resolvido de uma vez (pra manter fidelidade caso o efeito tenha
  escolhas que podem variar entre os dois disparos).
- **Não dobra habilidades ativadas nem estáticas** — só gatilhos ("whenever"),
  e só de criaturas do tipo escolhido. Enchantments/artifacts/instants/sorceries
  nunca são afetados, mesmo compartilhando o tipo tribal via texto solto. Vale
  mesmo quando a MESMA carta tem gatilho e ativada juntos (ex: Selvala e
  Marwyn no Thranduil - a habilidade de mana delas, que é ativada, nunca dobra,
  só o gatilho de compra/contador).
- Se o gatilho é do tipo "at least once per turn" ou similar auto-limitado no
  próprio texto da carta, o Roaming Throne dispara essa mesma instância de
  novo (não permite burlar o limite gerando um segundo disparo por evento
  subsequente no mesmo turno) - ex: Elrond e Elvish Warmaster no Thranduil.
- Alguns gatilhos alvejam o OPONENTE (mill/exile na biblioteca dele, dano,
  contadores negativos na criatura dele) e não têm efeito numérico modelável
  num goldfish solo sem oponente real em jogo - nesses casos, implementar
  como um contador de "disparou X vezes" sem side-effect no `GameState`
  próprio, e deixar isso documentado explicitamente (não inventar um efeito
  substituto).
- Alguns gatilhos são **negativos pro próprio jogador** (ex: Ruthless
  Winnower no Thranduil - sacrifica sua própria criatura não-Elfo a cada
  upkeep) - dobrar esses é uma PIORA, não uma melhoria. Sinalizar isso
  explicitamente ao reportar a métrica, não tratar toda duplicação como
  benéfica por padrão.
- Rastrear e reportar uma métrica agregada de "quantos gatilhos foram
  dobrados" pra medir o impacto real nos resultados do goldfish.

**Referência de implementação:**
- `thranduil-sultai/thranduil_goldfish_v1.py` (tipo escolhido: Elf) — função
  `roaming_throne_active()` no `GameState`, aplicada em `_apply_etb`,
  `_creature_cast_engines_trigger` e `combat_step`.
- `beorn-fierce/beorn_goldfish_v1.py` (tipo escolhido: Bear, já que a própria
  Beorn e `Legendary Creature — Bear Shapeshifter Warrior`) — mesmo padrão de
  `roaming_throne_active()`, aplicado em `combat_step` dobrando o próprio
  gatilho de combate da Beorn (converte criatura em Urso + checa 3+ Ursos).
- `edgar-markov-mardu/edgar_markov_goldfish_v1.py` (tipo escolhido: Vampire) —
  Passo 0 achou 16 vampiros com gatilho próprio (de 20 + o próprio Edgar
  Markov). Todos implementados como mecânica real via helper `_times()` +
  `_log_doubling()`: Eminence do comandante (token por vampiro conjurado),
  contador de ataque do próprio Edgar, Sanctum Seeker, Champion of Dusk,
  Welcoming Vampire, Clavileño First of the Blessed, Vito Fanatic de
  Aclazotz (3 estágios de sacrifício), e o pacote de morte (Blood Artist/
  Cruel Celebrant/Cordial Vampire/Vindictive Vampire/Vein Ripper) via um
  loop de sacrifício.

**Nota geral:** o tipo escolhido pelo Roaming Throne é sempre o tema tribal
central do deck (Elf, Bear, o que for) — quase nunca ambíguo na prática.
Documentar a premissa no código se não for óbvio olhando a decklist.

---

## Teste de robustez antes de rodar o batch oficial

Adicionada a partir da sessão do Toph, the First Metalbender (2026-08-22):
construindo um simulador que cobre 16 motores diferentes (não 1 ou 2),
5 bugs reais só apareceram rodando um volume grande de partidas com seeds
aleatórias — nunca nos primeiros testes manuais com 1-2 seeds fixas:

- Estado nunca conjurado por estar numa zona (comando) que a lógica de
  casting não verificava.
- Loop infinito por mutar `battlefield`/lista equivalente durante uma
  iteração `for` sobre ela mesma (clone de token entrando na lista sendo
  iterada).
- `ValueError`/crash em efeitos que sacrificam/removem múltiplos
  permanentes de uma lista pré-computada, quando processar o primeiro
  dispara uma cadeia que já removeu o segundo por outro caminho.
- `RecursionError` por um efeito "copiar permanente" não excluir cópias/
  tokens do próprio gatilho que a criou (a carta real diz "outro
  permanente **não-token**" — a implementação inicial não tinha essa
  distinção).
- `RecursionError` por refatoração via find-and-replace em massa
  reescrever a própria linha *dentro* da função que estava sendo chamada
  em todos os outros lugares, criando autorrecursão.

**Prática obrigatória antes de considerar um simulador novo pronto pra
rodar o batch oficial:** rodar uma amostra grande (10.000-20.000 partidas)
com seeds sequenciais e um timeout curto por partida (ex:
`signal.alarm(2)` em Python) capturando exceções e travamentos, **antes**
de rodar o batch de n= pequeno que vira o resultado reportado. Só reportar
resultado depois de zero erros/travamentos nessa varredura.

---

## Checklist obrigatória de categorias de mecânica (não só cartas individuais)

Adicionada por pedido explícito do usuário (sessão do Beorn, 2026-08-28), depois
de eu entregar um simulador (`beorn_goldfish_v1.py`) que **não tinha nenhum
despacho de landfall**, apesar de 6 cartas do deck dependerem dele. Citação
literal: *"Como diabos vc criou um simulador que não leva em conta a porra do
Landfall??? Por tudo que é mais sagrado, acrescente uma maldita regra de
conferir TODAS AS MALDITAS INTERAÇÕES, ATIVAÇÕES e COMBOS do deck na porra do
simulador. Revise gatilhos, tokens, motores de draw e ramp, e os mana dorks,
mana rocks e lands que geram mana fixing em TODOS OS DECKS E SIMULADORES!!!!"*

O "Passo 0" da seção do Roaming Throne acima (varredura mecânica em
`oracle_text`, não de memória) já existia mas só era aplicado à carta que
estava sendo implementada no momento — não como checklist obrigatória pra
QUALQUER simulador, novo ou já existente. Generalizando: antes de considerar
**qualquer** simulador (novo ou em revisão) completo, rodar essa varredura pra
**cada uma** destas categorias, sobre o `oracle_text` real de toda a decklist:

1. **Landfall** — toda carta com "Landfall —" no oracle_text precisa de um
   despachante real chamado em TODO ponto onde um terreno entra em campo: o
   land-drop normal E qualquer terreno buscado por rampa (Cultivate, Nature's
   Lore, Sakura-Tribe Elder, Solemn Simulacrum, etc — a regra de landfall não
   distingue a origem do terreno).
2. **Mana dorks** (criaturas com habilidade de `{T}: Adicionar mana`) —
   conferir (a) se contam pra mana total/fontes coloridas do turno, E (b) se
   respeitam doença de invocação (não produzem mana no turno em que entram,
   CR 302.6) — criatura sem haste não usa habilidade de `{T}` no turno da ETB.
3. **Mana rocks** (artefatos de mana) — não têm doença de invocação (só
   afeta criaturas), mas conferir se o custo de ativação extra (ex: Cabal
   Coffers) e restrições de cor estão implementados corretamente, não só um
   "+1 mana" genérico.
4. **Lands/efeitos de mana fixing** — terrenos ou permanentes que mudam o tipo
   de mana disponível (ex: Yavimaya Cradle of Growth virando todo terreno em
   Floresta, Cavern of Souls/Secluded Courtyard/Haven condicionados a tipo de
   criatura — ver regra #6 do `user-standing-rules.md`) precisam entrar na
   contagem real de fontes por cor, não só "incolor" por padrão.

   **Arquétipo de entrada de CADA terreno da lista, verificado via Scryfall**
   (regra #12 do `user-standing-rules.md`, citação literal do usuário depois
   de perguntar sobre Sundown Pass: *"Sempre implemente a verificação de
   todos os tipos de terrenos: fetch, checked, shock, triomas e etc!"*) —
   nunca presumir "provavelmente destravada" por semelhança com outro
   terreno já cadastrado:
   - **Fetch** ("Sacrifice ~: Search your library for a [tipo] card") —
     `crack_fetch()`/`FETCH_TARGETS`, alcança qualquer terreno com o tipo
     buscado (Regra 6), não só o par nomeado.
   - **Shock land** ("you may pay 2 life. If you don't, ~ enters tapped") —
     convenção já documentada nesta sessão: assume que o jogador sempre paga
     a vida (vida não é recurso rastreado/escasso no simulador), então NUNCA
     entra tapped — mas isso é premissa explícita, não ausência de checagem.
   - **Check land** ("~ enters tapped unless you control a [tipo] or
     [tipo]") e **slow land** ("~ enters tapped unless you control two or
     more other lands") — exigem uma condição REAL sobre o estado do campo
     no momento em que o terreno entra (contagem de tipos ou de terrenos já
     em campo); nenhum desses dois arquétipos tinha suporte genérico no
     simulador antes de 2026-08-29 (achado real: Sundown Pass, "check land"
     R/W, ia ser cadastrada como sempre-destravada por conveniência sem essa
     regra). Implementar de forma reutilizável (função genérica, não
     hardcoded pra 1 carta), condicionada ao `len(state.battlefield)`
     filtrado por `LAND_NAMES` no momento da entrada.
   - **Triome / sempre tapped** ("This land enters tapped", sem condição
     nem opção de vida) — `ETB_TAPPED_LANDS`, incondicional.
   - **Pain land** ("{T}: Add [cor]. This land deals 1 damage to you") —
     nunca tapped; vida não rastreada (mesma premissa dos shocks).
   - **Canopy/horizon land** (sacrifício + draw), **dual original** (sem
     restrição nenhuma), **terreno sem-cor de mana dupla** (ex: Ancient
     Tomb) — conferir o oráculo exato antes de assumir que se encaixa num
     desses baldes só pelo nome ou aparência.
   - Aplica-se **retroativamente a toda manabase de todo deck do
     repositório** — auditar a lista inteira contra esses arquétipos antes
     de declarar qualquer simulador (novo ou revisado) completo.
5. **Motores de draw** ("Whenever you cast/draw/creature enters... draw a
   card") — cada um precisa de um gatilho real, disparado no evento certo
   (cast vs. ETB são momentos diferentes; a maioria dos simuladores atuais
   trata os dois como intercambiáveis, o que é aceitável só se documentado).
6. **Motores de ramp** — incluindo os que buscam terreno específico (básica
   vs. Floresta vs. qualquer terreno — conferir contra o oracle_text exato,
   não assumir "qualquer terreno da lib" quando a carta diz "basic land" ou
   nomeia um tipo).
7. **Habilidades ativadas repetíveis** (token makers, sacrifice outlets,
   descarte-por-valor como Ayula's Influence) — se a carta tem um custo
   pagável mais de uma vez por turno/jogo, o simulador precisa decidir e
   documentar uma heurística de quando a IA ativa (não pode ficar de fora só
   porque "é ativada, não gatilho").
8. **Combos entre peças que já estão na decklist** — depois do passo 0 por
   carta individual, checar explicitamente se duas ou mais cartas já
   implementadas se combinam (ex: sac outlet + payoff de morte + motor de
   mana, ver o pacote Blood Artist/Zulaport do Edgar Markov) — um simulador
   pode ter cada carta implementada isoladamente e ainda assim errar a
   interação entre elas.
9. **Habilidades estáticas** (não são gatilho nem ativação — valem o tempo
   todo enquanto o permanente está em campo: anthems, custo reduzido,
   "criaturas que você controla são do tipo X", terrenos viram outro tipo,
   restrição/expansão de cor de mana, "não pode ser bloqueada", etc). Cada
   uma precisa estar aplicada de verdade em todo cálculo que ela afeta (ex:
   um anthem de +1/+1 tem que entrar em `BASE_POWER`/custo/combate em TODO
   lugar relevante, não só onde foi implementada primeiro) — não é
   suficiente ter a tag na definição da carta.
10. **Métricas básicas do relatório** — todo `run_batch`/resumo de simulador
    precisa reportar, de forma auditável e separada, pelo menos estas 5
    categorias agregadas, mesmo que o deck já tenha métricas específicas de
    carta: **ramp** (mana disponível/peças de aceleração), **draw** (compra
    extra além da normal do turno), **interaction** (remoção/proteção/
    interação com o oponente conjurada), **recursion** (recuperação de
    cartas do cemitério — pra mão, campo, ou topo da biblioteca: reanimação,
    tutor-de-volta, "return target card from your graveyard", etc — ver
    citação literal do usuário abaixo), **finisher/lethality** (taxa e turno
    médio de resolver um fechador de jogo). Se uma dessas 5 categorias não
    existe na decklist, documentar "0 cartas de X, categoria N/A" em vez de
    simplesmente omitir a métrica do relatório.

    Citação literal do usuário (2026-08-28), depois de eu reportar a
    checklist ampliada (estáticas + as 4 métricas originais) em Edgar
    Markov/Hei Bai: *"Vc precisa acrescentar a variável recursão e interação
    à lista de variáveis para avaliar, medir e registrar em todos os decks
    tb!"* — **recursão** entra como 5ª categoria de métrica básica (antes
    não estava na lista original de 4); **interação** já estava na lista,
    mas o reforço deixa explícito que precisa ser uma métrica agregada de
    verdade em TODO deck (não só citada como "N/A por arquitetura" sem uma
    linha própria no relatório) — todo deck com qualquer carta de
    remoção/proteção precisa de um número reportado pra ela, mesmo que o
    número seja 0 por design (goldfish solo sem oponente real).

11. **Cartas de face múltipla / modal (MDFC, transform, Room, Battle,
    Adventure, "Prepared")** — antes de registrar QUALQUER carta com "//"
    no nome (ou qualquer layout multi-face) no `CARD_DB`, consultar o campo
    `layout` real da API do Scryfall (não adivinhar pelo formato do nome) e
    verificar qual face é de fato jogável da mão:
    - **`modal_dfc`** (MDFC verdadeiro, ex: Agadeem's Awakening // Agadeem,
      the Undercrypt): as duas faces são independentemente jogáveis da mão
      — quem escolhe é o jogador no momento do cast/land-drop. Modelar as
      DUAS opções (mesmo que a escolha padrão seja sempre uma delas por
      falta de alvo real) — nunca registrar só uma face permanentemente sem
      checar se a outra faria diferença.
    - **`transform`** (ex: Ojer Taq // Temple of Civilization, Legion's
      Landing // Adanto): só a FRENTE é castável da mão — o verso só é
      alcançável via o gatilho real de transformação do jogo. Registrar a
      carta pela frente (tipo/custo/cor real dela), nunca direto pelo
      verso — isso seria simular uma ação ilegal (jogar como land/ativar
      uma carta que nunca foi conjurada), não só "perder valor".
    - **`split`** com mecânica de "Room" (ex: Funeral Room // Awakening
      Hall): permite destrancar a segunda porta depois, pagando o custo
      dela "as a sorcery" — não é um cast novo (não dispara gatilhos de
      "whenever you cast"), mas é uma ação real que precisa de dispatch.
    - **`battle`**: side do defensor com contadores de defesa, ataca-lo
      (do lado do jogador) exige um "attacking player" que esse tipo de
      simulador solo geralmente não modela — documentar explicitamente por
      que está fora de escopo, não silenciar.
    - **`prepare`** (ex: Emeritus of Woe // Demonic Tutor, Stensian
      Sanguinist // Exsanguinate): a carta entra "prepared" sob uma
      condição real (ver texto), permitindo conjurar uma cópia do verso
      SEM ter a carta física (mas ainda pagando o custo real dele, a menos
      que o texto diga "without paying its mana cost").
    - **Adventure**: o lado Instant/Sorcery pode ser conjurado primeiro
      (exila a carta, permite conjurar a criatura depois do exílio) — as
      duas metades são reais e call cada uma no tempo certo.

    Regra geral: **nunca registrar uma carta de face múltipla direto pela
    face "mais conveniente" de modelar sem antes confirmar, via `layout` da
    API, que essa é de fato uma face jogável da mão** — isso pode estar
    simulando uma ação ilegal do jogo inteiro, não só uma simplificação.

12. **Counters de lealdade e ativações de planeswalker** — citação literal
    do usuário (2026-08-28), depois de eu confirmar que o Prismatic Bridge
    não modelava NENHUMA habilidade individual dos 17 planeswalkers da
    lista, só rastreava se a Bridge acertou um: *"Preciso que os counters
    de lealdade e ativações de planeswalker sejam sempre contabilizados, a
    base do Prismatic Bridge é essa! Adicione essa regra para tudo, sempre
    também!"* Todo planeswalker em qualquer decklist precisa de:
    - Um campo de lealdade rastreado de verdade (`state.loyalty[nome]`),
      com a lealdade inicial real (Scryfall) e cada ativação alterando o
      valor de verdade — não um contador decorativo.
    - Uma decisão real de qual habilidade ativar a cada turno em que o
      planeswalker está em campo (respeitando "só uma ativação por turno,
      velocidade de feitiço" — CR 606.3), com heurística documentada (ex:
      prioriza ultimate quando alcançável, senão a habilidade de maior
      valor sem arriscar morrer à toa).
    - O efeito de cada habilidade implementado de verdade (draw, remoção
      proxy, wipe proxy, mana, contadores, tokens — a mesma convenção já
      usada no resto do simulador pra efeitos sem alvo real de oponente),
      não só a tag `"planeswalker"` decorativa.
    - Morte do planeswalker (lealdade chega a 0, ou removido por remoção do
      oponente se esse simulador já rastreia isso) rastreada e refletida no
      board.
    - **Janela de ativação (achado 2026-09-25, Prismatic Bridge):** todo PW
      que entra durante o main phase (conjurado da mão, posto em campo por
      tutor/saga, ficha-cópia) pode ativar **no mesmo turno**. Não existe
      doença de invocação pra lealdade (CR 606.3: "any time they have
      priority and the stack is empty during a main phase of their turn").
      O bug achado foi de ORQUESTRAÇÃO (Regra #6): a única passada de
      ativação rodava ANTES do loop de conjuração, então PW conjurado só
      ativava no turno seguinte. A correção subiu as ativações em +54% e os
      ultimates em +61%. Em todo simulador com PW, conferir que existe uma
      passada DEPOIS de cada entrada no main phase, não só a do começo.

13. **Cartas com "níveis" — Classes e Sagas** — citação literal do usuário
    (2026-08-28), depois de eu deixar Caretaker's Talent (Hei Bai) e
    Innkeeper's Talent (Prismatic Bridge) só na habilidade base, "nível
    2/3 fora de escopo" sem checar o texto real de cada nível: *"Não
    esqueça de verificar as cartas com 'níveis', como classes e sagas. Vc
    tb precisa criar a regra de verificar e contabilizar isso, pq o
    caretaker's talent se elevado ao nível 3 aumenta todos as token
    creatures e o innkeeper's no Prismatic no nível 3 DOBRA TODOS OS
    COUNTERS, inclusive os de lealdade de PWs ao entrarem no jogo!"*
    - **Classes**: ganham nível seguinte "as a sorcery" pagando um custo
      real (`{custo}: Level N`), cada nível adiciona uma habilidade NOVA
      (não substitui as anteriores — todas ficam ativas simultaneamente).
      Antes de decidir "só a base é modelada", ler o texto de TODOS os
      níveis (Scryfall lista cada um) — um nível alto pode ser um efeito
      de campo inteiro (anthem, dobrador de counter) que muda
      completamente o valor real da carta, não um extra menor.
    - **Sagas**: ganham um marcador de lore automaticamente ao entrar e
      após cada compra própria (não é pago, é automático) — cada capítulo
      soma uma habilidade nova, sacrifica após o último capítulo. Um
      capítulo do meio pode conceder uma habilidade ativada que compete
      pelo mesmo `{T}` da habilidade de mana da carta (ex: Urza's Saga
      capítulo II) — não pode ser "grátis" ao lado da mana, é uma escolha
      real por turno.
    - Vale pra **todo deck do repositório**, não só os 2 que motivaram a
      regra — qualquer Class/Saga em qualquer decklist precisa ter TODOS
      os níveis/capítulos conferidos contra o oráculo real antes de
      decidir o que é modelável.
    - **Saga também recebe lore de outras fontes (achado 2026-09-25):**
      proliferate (CR 701.34a, "any number of permanents ... that have a
      counter") e "double the counters" (Deepglow Skate) põem lore, e o
      capítulo dispara igual (CR 714.2b). É ESCOLHA do jogador (pode deixar
      a saga de fora), então a política tem que decidir se o capítulo vale
      agora, e não aplicar sempre nem nunca.

**Prática obrigatória:** antes de declarar QUALQUER simulador (novo ou já
existente, numa auditoria de revisão) completo, rodar essa checklist e citar
explicitamente, por categoria, quantas cartas da decklist se qualificam e se
cada uma tem implementação real — não só reportar "achei um bug, corrigi".
Se uma categoria não se aplica a um deck (ex: deck sem nenhuma carta de
landfall), documentar isso também ("0 cartas de landfall na lista, categoria
N/A"), pra deixar claro que a categoria foi checada e não só ignorada. Isso
vale **sempre**, em qualquer sessão, pra qualquer deck do repositório — não
só o deck sendo discutido no momento em que a regra foi criada ou reforçada.

---

## Teste comparativo pareado: substituir a carta cortada NA MESMA POSIÇÃO da lista, nunca `list.append()` a nova

Achado real (Ur-Dragon, 2026-08-29), durante o teste de qual carta cortar
pra abrir espaço pra Magda, Brazen Outlaw: o padrão usado em TODOS os
scripts de teste comparativo desta sessão até aqui
(`urdragon_morophon_test.py`, `urdragon_primer3_test.py`) constrói a
variante assim:

```python
lib = sim.BASE_LIBRARY[:]
lib.remove(cut_name)
lib.append(add_name)          # <-- ERRADO: sempre no fim da lista
```

Isso parece inofensivo (o baralho ainda tem as 99 cartas certas), mas
**quebra o pareamento de seed**: `rng.shuffle(lib)` é uma permutação de
Fisher-Yates, cujo resultado exato depende da posição de CADA elemento na
lista original, não só do conteúdo. Colocar a carta nova sempre no índice
98 (fim), quando na `lista.md` real ela ocuparia o índice de onde a
cortada saiu (no meio da lista), faz a MESMA seed embaralhar as duas
listas de formas diferentes — a mão inicial e a ordem de compra deixam de
ser comparáveis "tudo igual, exceto a troca", viram efetivamente 2
amostras semi-independentes.

**Grandeza real do erro medido:** testando Magda no lugar de Rhythm of
the Wild, o método com `.append()` deu **+7,0% de dano proxy** (1136,21
vs. baseline 1061,50) — parecia uma troca claramente boa. Reconstruindo a
`lista.md` com a substituição NA MESMA LINHA/posição (`text.replace("1
Rhythm of the Wild", "1 Magda, Brazen Outlaw")`, depois reparseando o
texto inteiro do zero, igual ao `build_library()` real) deu **-1,3% de
dano proxy** (1047,30) — troca de sinal completo, de "ganho claro" pra
"levemente pior, mas ainda a melhor entre as candidatas testadas". A
RANKING relativa entre candidatas testadas no mesmo lote (todas com o
mesmo bug) tendeu a se manter (Rhythm of the Wild continuou sendo o
melhor corte mesmo corrigido), mas a MAGNITUDE reportada estava errada, e
não há garantia de que a ranking sempre sobrevive à correção — precisa
reverificar, não presumir.

**Prática obrigatória a partir de agora, em qualquer teste comparativo
pareado (`urdragon_*_test.py` e equivalentes de outros decks):**
- Construir cada variante a partir do TEXTO da lista real (`lista.md` ou
  equivalente), com `str.replace()` na linha exata da carta cortada pela
  carta nova, e só then reparsear com a mesma função que `build_library()`
  usa de verdade — nunca `list[:] ; .remove() ; .append()`.
- Rodar o batch oficial (script principal, lendo o arquivo real já
  editado) é sempre o número final confiável, mesmo que os testes
  exploratórios de ranking tenham usado o método errado — batches oficiais
  desta sessão (`python3 urdragon_goldfish_v1.py` lendo `lista.md`
  diretamente) não tinham esse bug, porque leem o arquivo de verdade via
  `build_library()`, que preserva a posição real de cada carta.
- Se uma decisão de troca foi tomada com base só no teste exploratório
  (`.append()`), reverificar com a reconstrução posicional antes de
  reportar o número ao usuário como final — a ranking pode sobreviver, a
  magnitude quase sempre muda.

---

## Redução de custo só abate mana GENÉRICO — usar o `mana_cost` real

Achado real (Prismatic Bridge, 2026-09-25): o desconto do Tamiyo's
Notebook ("Spells you cast cost {2} less") usava `mv - len(colors)` como
parte genérica. Isso erra toda carta com 2+ símbolos da mesma cor. Nicol
Bolas, Dragon-God é {U}{B}{B}{B}{R}: genérico 0, e a aproximação dava 2.
Counterspell {U}{U} caía pra 1. Redução de custo ("costs {N} less") só
abate genérico (CR 601.2f). Em todo simulador com redutor de custo, montar
uma tabela de genérico real a partir do `mana_cost` do cache (híbrido e
phyrexiano contam como símbolo colorido). Nunca derivar o genérico da
identidade de cor.

## A/B de carta: nunca comparar MÉDIA de contagem sem teto

Achado real (Prismatic Bridge, 2026-09-25): em partidas já ganhas o motor
entra em loop (Oko −5 copiando Doubling Season, Gauntlet −12, Chain Veil).
Aí aparecem 80+ "ultimates" e lealdade na casa dos bilhões numa partida só.
Uma carta que acelera a chegada nesse estado em 1 partida a mais em 100
move a média de ultimates em +2. O número parece enorme, mas não diz nada
sobre o jogo real. Pra decidir inclusão ou corte, usar só métricas
limitadas por partida:
- turno do 1º ultimate;
- P(ultimate até o T8);
- turnos com ultimate (no máximo 10);
- morte/vida no modo de resiliência;
- PW-turnos vivos.
Sempre reportar diferença pareada com IC95%, e contagem ilimitada só como
métrica de uso da carta.


## Gatilho do turno do OPONENTE modelado no meu turno: a criatura criada nasce "ontem"

Achado real (Ur-Dragon + Draconic Visitor, 2026-09-25). Smothering Tithe
("Whenever an opponent draws a card...") é modelada como 1 Treasure no
MEU upkeep. Pra Treasure isso é neutro: a mana fica disponível no meu
turno do mesmo jeito. Mas quando uma substituição transforma o produto em
CRIATURA (Draconic Visitor: Treasure → Dragão 5/5), a posição do proxy
muda o resultado. A ficha nascia doente no meu turno, sendo que na mesa
real ela entrou no turno do oponente e ataca no meu. Regra: todo proxy de
gatilho que acontece fora do meu turno precisa marcar o turno de entrada
da ficha como `turno - 1` (sem doença de invocação), nunca `turno`.

## Métrica de letalidade: "each opponent loses N" vale N × oponentes

Achado real (Vihaan, 2026-09-25). O contador histórico de drain somava 1
por gatilho, seja "each opponent loses 1" (Zulaport) ou "target opponent
loses 1" (Sephiroth). Pra uma métrica de letalidade da mesa (3 × 40 =
120) isso mistura unidades. Dano de combate e "target"/"any target"
contam N; "each opponent" conta N × NUM_OPPONENTS. Manter o contador
antigo pra comparabilidade histórica e criar um contador novo com peso.

## A/B de carta cara ou tardia: condicional + decomposição, não só o incondicional

Achado real (Draconic Visitor, 2026-09-25). A mesma carta resolve em 44%
das partidas no Ur-Dragon (motor de compra e redutores) e em 8% no Vihaan.
O A/B incondicional dá "neutro" nos dois, mas por motivos opostos: diluído
no Vihaan, e efeito teto no Ur-Dragon (as partidas em que ela resolve já
estão ganhas). Pra toda carta candidata de MV ≥ 5 ou dependente de
motor, reportar também:
1. a frequência de resolução por deck;
2. o condicional, só nas seeds em que ela entrou, com horizonte maior se
   ela chega tarde;
3. a **decomposição**: a carta × um corpo genérico de mesmo custo, cor e
   tipo, no mesmo slot, só no harness. A diferença é o valor do TEXTO
   naquele deck. É isso que responde "em qual deck ela é melhor".

## A/B de carta: dano por limiar, proteção por dano recebido, e controle de entrada

Achado real (Prismatic Bridge, 2026-09-29, Dihada/Guff/Vronos/Sarkhan).
1. **Dano de combate: usar P(dano ≥ 40) e P(dano ≥ 120), não a média.** O proxy
   é dominado pelas partidas em loop. A média com teto de 1000 dava sobre a
   base um sinal que contradizia o efeito real da Sarkhan (Δ −5,1 ±5,9 contra
   +6,2 pp de P(dano ≥ 40) sobre o PW inerte). 40 = uma vida de oponente; 120 =
   a mesa de 3.
2. **Carta de proteção (phase out, hexproof) não aparece em "PWs mortos".** O
   oponente simulado bate no de maior lealdade fora de fase e desvia o dano
   pro resto, então o total de mortes não muda. Medir dano recebido pelos
   permanentes protegidos, soma de lealdade no fim e comparar a carta com a
   MESMA carta sem a habilidade (chave `CAND_POLICY` desligada no harness).
3. **Sempre incluir o corpo genérico (PW inerte).** Ele separa "é mais um PW"
   e o valor do slot cortado do valor do texto. Sem ele o A/B contra
   Arena Rector misturava tudo (o slot vale ~0,065 de 1º ult na resiliência).
4. **Sensibilidade por chave de política**, uma de cada vez. Mostrou que o
   valor da Dihada vem todo do −3, o da Guff do gatilho e não do −3, e o da
   Sarkhan do +1 (animação) só no dano.

## Processo: resposta idêntica em todos os cenários exige controle positivo

Os 6 resultados do Commander Spellbook (base, 4 cartas, as 4 juntas) tinham
exatamente o mesmo tamanho em bytes. Isso pode ser "nenhuma das cartas está
em combo" ou "a requisição não mudou". Antes de afirmar "0 combos novos",
rodar um controle positivo: remover uma carta que ESTÁ em combos (a Chain
Veil derrubou 4) e ver a resposta mudar. Guardar o script (`csb.py`), não só
os JSONs.

## Processo: nunca `pkill -f`/`pgrep -f` com padrão que aparece no próprio comando

Aconteceu 2× nesta sessão. O padrão aparece na linha de comando do
próprio shell, então o `pgrep` casou com ele e o `pkill` derrubou o shell
junto (exit 144). Listar com `ps aux | grep ... | grep -v grep` e matar
por PID.

Reincidência (2026-09-28, mais 2×): `ps aux | grep "[a]b_x" | xargs kill`
no MESMO comando que depois relança `nohup python3 ab_x ...` também mata o
shell: o truque do colchete impede o grep de casar consigo mesmo, mas a
linha do `bash -c` contém o nome do script por extenso mais adiante. Um
laço `until ! pgrep -f "regress.py std"` também nunca termina, pelo mesmo
motivo. Regra: **listar PIDs num comando, matar por número em OUTRO
comando**; nunca listar/matar e relançar na mesma chamada.

## Efeito que transforma permanente em TERRENO não dá habilidade de mana

Achado real (Toph, 2026-09-26). O simulador somava 1 de mana pra todo
terreno, e a Toph ("Nontoken artifacts you control are lands ... (They
don't gain the ability to {T} for mana.)") transforma todo artefato em
terreno. Resultado: Skullclamp, Crucible e KCI geravam mana, e Sol Ring e
Great Henge caíam de 2 pra 1 porque o ramo "terreno" vinha antes do ramo
"rock". Regra: mana é **por permanente**, pela melhor habilidade de mana
que ele TEM. As fontes possíveis são:
- habilidade própria;
- tipo básico de terreno (Forest dá {G}, inclusive o tipo concedido por
  Yavimaya, Prismatic Omen, Dryad ou Ashaya);
- concessão explícita (Wrenn and Realmbreaker, Great Divide Guide,
  Enduring Vitality).

Todo deck com "X are lands" (Toph, Ashaya, Mycosynth + Toph) precisa
desse modelo.

## Mana gerada por gatilho precisa ser gastável na mesma fase

Achado real (Toph, 2026-09-26). A mana de Lotus Cobra/Nissa (landfall) e
do Krark-Clan Ironworks ia só pra uma métrica `mana_generated_extra` e
nunca podia pagar nada. Esse é o inverso da "mana fantasma" da taxonomia:
a mana existe mas não pode ser usada. Treasure, por outro lado, nunca era
sacrificado e virava 1 mana por turno pra sempre. Regra: toda mana gerada
entra num pool flutuante que esvazia ao fim da fase, e todo recurso gasto
sai de campo. Precisa haver uma fase principal **pós-combate** pra mana de
combate (untap do Avatar Kyoshi, Sword of Feast and Famine).

## Fetch: a própria fetch dispara landfall

Achado real (Toph, 2026-09-26). A fetch entra (landfall 1), é quebrada, e
o terreno buscado entra (landfall 2). O simulador pulava a entrada da
fetch. Além disso, "Search for a Mountain or Plains card" aceita qualquer
carta com o TIPO, não só básico. Vale pra todo deck com landfall.

## Checagem de cor: uma fonte paga UM pip (condição de Hall)

Achado real (Ur-Dragon, 2026-09-28). `has_color_sources_for` checava cada
cor sozinha. Um Command Tower contava como fonte de W, U, B, R e G ao
mesmo tempo, então Command Tower + 5 Forest "pagava" WUBRG. O certo:
- uma entrada por fonte pronta, com o conjunto de cores que ela produz;
- pra todo subconjunto S das cores exigidas, pips(S) ≤ fontes que
  produzem alguma cor de S.
Mana restrita que é colorida conta como fonte só pro tipo de magia
permitido: Orb of Dragonkind ("two mana in any combination of colors"),
Cavern, Haven. Junto com "redução só abate genérico" (acima), é o par que
decide se carta de 5 cores é conjurável.

## "Look at the top N" nunca é busca na biblioteca inteira

Achado real (Ur-Dragon, 2026-09-28). O sacrifício da Orb of Dragonkind
("Look at the top seven cards ... reveal a Dragon card from among them")
buscava na biblioteca inteira: virou tutor completo. O risco real da linha
é o topo 7 vir sem alvo. Nesse caso a carta sai por nada, e o resto vai
pro fundo na ordem que o oráculo manda.

## Categoria nova no modo de resiliência reabre todo 📊 que citava a ausência dela

Achado real (Ur-Dragon, 2026-09-28). Em 2026-08-29, Cavern of Souls
("can't be countered"), Rhythm of the Wild, Dragonlord Dromoka ("Your
opponents can't cast spells during your turn"), Heroic Intervention,
Teferi's Protection e o shroud do Lightning Greaves foram marcados 📊
"sem contramágica/remoção de oponente". Em 2026-09-20 o modo de
resiliência ganhou contramágica, wipe e remoção, e ninguém voltou nessas
cláusulas. Heroic e Teferi ficaram mortas na mão durante esses 8 dias
de modo de resiliência.

Regra: ao adicionar uma categoria de ação de oponente (contramágica,
wipe, remoção, ataque, descarte, hate de cemitério) a qualquer simulador,
grepar no MESMO arquivo toda nota 📊/`opponent_dependent`/`interaction`
que cita essa categoria. Ligar as respostas no mesmo commit.
Consequência pra A/B: a carta cujo valor está nessas cláusulas aparece
subestimada. Cortar por esse número é o erro da Regra #5.

## Compra obrigatória em massa: modelar deck-out (CR 704.5b) e a escolha de atacantes

Achado real (Ur-Dragon, 2026-09-28). "Draw that many cards" da Ur-Dragon
é obrigatório e resolve na declaração de ataque, antes do dano. O
simulador só levantava uma flag `library_emptied` e seguia, marcando
letal no fim do turno. Resultado: 16% das partidas eram "letais" num turno
em que o piloto teria decado antes do dano.

Regra, pra todo simulador com compra em massa (gatilho de ataque,
ETB-draw por ficha, "draw X"):
1. comprar de grimório vazio = derrota; a partida para;
2. letal só vale se o dano já tinha passado do limiar antes da compra
   fatal;
3. o piloto controla a alavanca real (quantos atacam, quais compras
   opcionais aceita) e usa isso pra não decar.

## Treasure é PERMANENTE: estoque persistente, conta pra qualquer "Sacrifice N Treasures"

Achado real (Ur-Dragon, 2026-09-28, avaliando a Magda). O simulador
convertia Treasure em mana na hora (o que sobrava sumia no fim do turno) e
a Magda tinha um contador separado só com os Treasures DELA. Erros: o
Treasure do Goldspan/Old Gnawbone/Ancient Copper/Smothering Tithe nunca
contava pro "Sacrifice five Treasures", e Treasure não gasto não passava
pro turno seguinte. Corrigido com `treasure_stock`: o estoque entra no
total de mana, gasta só o que foi preciso (terrenos e rocks primeiro), o
resto persiste, e o tutor sacrifica o que sobrou. Efeito medido: letal até
o T8 50,4% → 54,7%, comandante 0,13 turno antes. Vale pra todo deck com
Treasure (Vihaan, Megatron, Toph, Ulalek...): grep de `bonus_mana_pool` em
código de Treasure.

## Changeling é Dwarf/Dragão/tudo, em toda zona: varrer o conceito, não a carta

Achado real (Ur-Dragon, 2026-09-28). Magda dispara em "a Dwarf you control
becomes tapped". Firdoch Core e Morophon têm Changeling, então são Dwarf.
O simulador só conhecia o Firdoch; o Morophon atacando (vira) não gerava
Treasure e a Magda não dava +1/+0 a nenhum dos dois. Regra: pra todo
gatilho/estático por tipo de criatura, listar por script, em `type_line` +
`oracle_text` ao vivo, quem satisfaz (Changeling inclusive), e propagar pra
fichas-cópia (Miirym) e pro Sarkhan, Soul Aflame copiando.

## Política de descarte do cleanup antes da comandante

Achado real (Ur-Dragon, 2026-09-28, avaliando a Tiamat). O descarte pegava
o menor custo, terreno primeiro, mesmo antes da comandante de 9 estar em
campo. Com uma carta que põe +5 na mão, isso jogava fora Herald's Horn e
ramp pra guardar Dragão de 7. Carta que enche a mão só pode ser avaliada
com uma política de descarte que proteja o plano. Conferir essa política
antes de rodar A/B de tutor ou draw em massa.
## Habilidade ativada de tutor: medir a ORDEM na fase antes de concluir que ela "funciona"

Achado real (Prismatic Bridge, 2026-09-29, Sisay). A primeira política pôs a
busca DEPOIS do loop da mão (só antes quando o alvo custava 6+). Rodou, disparou,
trouxe PW, e o A/B deu −0,069 de 1º ult. Medindo a outra ordem (busca antes da
mão, o mana da fase vai primeiro pro tutor) deu −0,086, e no terceiro slot
mudou o veredito contra o Entrust. Habilidade sem {T} e sem restrição de
timing tem uma janela de ordem dentro do main phase; a ordem entra no harness
como chave de política (`@sisay_pre_hand_all`), com as duas medidas no log.
Outras duas lições do mesmo achado: (1) o oráculo que eu lembrava estava
errado (poder = maior MV; o real é +1/+1 por cor entre OUTRAS lendárias),
então buscar ao vivo antes de escrever código não é opcional; (2) uma chamada
extra de `activate_unactivated_planeswalkers` depois do main phase mudou a
base sem a carta em campo, só a bit-identidade da lista atual pegou. Chamada
nova só quando a ação de fato aconteceu (retorno inteiro > 0).

Reincidência de `pgrep -f`: um laço `until [ -f done ] && ! pgrep -f
bitident.py` dentro de `bash -c` nunca terminou, porque a linha do próprio
`bash -c` contém "bitident.py". Esperar por ARQUIVO de sinal (`done.txt`
escrito pelo script), nunca por `pgrep -f` do nome do script.

## Comparar duas cartas que "fazem a mesma coisa": instrumentar a fonte de cada evento e refazer a varredura de prosa

Achado real (Prismatic Bridge, 2026-09-29, Sisay no lugar da Arena Rector). Três erros meus de uma vez, todos pegos só
porque o usuário propôs uma troca direta e eu fui olhar o que a carta cortada FAZ no simulador:
1. **Prosa antiga virou "fato".** O log dizia "a lista não tem NENHUM outlet de sacrifício de criatura" e usava isso pra
   chamar a Arena Rector de carta morta. Liliana −4, Eternal Wanderer −4 e 4 wipes eram outlets de propósito, e o simulador já
   os modelava. Antes de reusar uma afirmação negativa ("não tem X") de um doc antigo, refazer a varredura ao vivo e
   grepar `NENHUM|nunca|não tem` nos docs do deck.
2. **Regex por texto perde efeito escondido em modo alternativo.** A varredura por "each creature" não achou o Damn (o
   "each" só aparece no overload). Depois da varredura por texto, rodar uma segunda por ALVO ("destroy target", "damage to
   target") e uma por palavra-chave de modo (overload, kicker, escape).
3. **Política do simulador que só aparece na fonte do evento.** Instrumentando `_our_creature_leaves` por `source`, a Liliana
   −4 apareceu sacrificando a Sisay em 8% das entradas, embora o −4 seja escolha do jogador. Toda comparação de duas
   criaturas deve imprimir de onde vêm as mortes de cada uma (combate, wipe próprio, outlet, wipe de oponente).
Complemento: "a carta vale pouco no simulador" só vale depois de perguntar qual linha DELIBERADA falta (aqui: Damn/Void Rend na
própria Arena Rector). Modelei como chave desligada por padrão e medi o teto: −0,009 turno, o que confirmou o A/B em vez de
mudar a conclusão. Fazer a medição do teto antes de reclamar que o simulador subestima uma carta.

---

<!-- Adicionar novas entradas abaixo conforme surgirem cartas com efeitos
     estruturais que exigem implementação explícita (não só tag) em qualquer
     simulador que as inclua. -->
